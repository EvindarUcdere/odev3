﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cizim
{
    public  class UretimVerisi
    {
        public string MakineAdi { get; set; }
        public DateTime Tarih { get; set; }
        public int HedefMiktar { get; set; }
        public int UretilenMiktar { get; set; }
    }
}
